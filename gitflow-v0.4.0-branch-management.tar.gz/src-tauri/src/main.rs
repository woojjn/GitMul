// Prevents additional console window on Windows in release
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod commands;

#[cfg(test)]
mod tests;

use commands::{
    git::{
        open_repository, 
        get_commit_history, 
        get_repository_status,
        stage_file,
        unstage_file,
        stage_all,
        create_commit
    },
    repos::{get_recent_repos, add_recent_repo},
    branch::{
        list_branches,
        create_branch,
        switch_branch,
        delete_branch,
        rename_branch,
        get_current_branch
    }
};

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            open_repository,
            get_commit_history,
            get_repository_status,
            stage_file,
            unstage_file,
            stage_all,
            create_commit,
            get_recent_repos,
            add_recent_repo,
            list_branches,
            create_branch,
            switch_branch,
            delete_branch,
            rename_branch,
            get_current_branch
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
