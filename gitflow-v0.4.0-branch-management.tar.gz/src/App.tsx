import { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/tauri';
import { open } from '@tauri-apps/api/dialog';
import Sidebar from './components/Sidebar';
import CommitHistory from './components/CommitHistory';
import FileChanges from './components/FileChanges';
import CommitDialog from './components/CommitDialog';
import { FolderOpen, Moon, Sun, GitCommit } from 'lucide-react';

export interface RecentRepo {
  path: string;
  name: string;
  last_opened: number;
}

export interface RepositoryInfo {
  path: string;
  branch: string;
  remote_url?: string;
}

export interface CommitInfo {
  id: string;
  author: string;
  email: string;
  message: string;
  timestamp: number;
  date: string;
  parent_ids: string[];
}

export interface FileStatus {
  path: string;
  status: string;
  staged: boolean;
}

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [recentRepos, setRecentRepos] = useState<RecentRepo[]>([]);
  const [currentRepo, setCurrentRepo] = useState<RepositoryInfo | null>(null);
  const [commits, setCommits] = useState<CommitInfo[]>([]);
  const [fileChanges, setFileChanges] = useState<FileStatus[]>([]);
  const [loading, setLoading] = useState(false);
  const [commitDialogOpen, setCommitDialogOpen] = useState(false);

  useEffect(() => {
    loadRecentRepos();
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const loadRecentRepos = async () => {
    try {
      const repos = await invoke<RecentRepo[]>('get_recent_repos');
      setRecentRepos(repos);
    } catch (error) {
      console.error('최근 레포 로드 실패:', error);
    }
  };

  const openRepository = async (path?: string) => {
    try {
      let repoPath = path;
      
      if (!repoPath) {
        const selected = await open({
          directory: true,
          multiple: false,
          title: 'Git 레포지토리 선택',
        });
        
        if (!selected || Array.isArray(selected)) return;
        repoPath = selected;
      }

      setLoading(true);
      
      const repoInfo = await invoke<RepositoryInfo>('open_repository', { path: repoPath });
      setCurrentRepo(repoInfo);
      
      await invoke('add_recent_repo', { path: repoPath });
      await loadRecentRepos();
      
      await loadCommits(repoPath);
      await loadFileChanges(repoPath);
      
    } catch (error) {
      alert(`레포지토리 열기 실패: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const loadCommits = async (path: string) => {
    try {
      const history = await invoke<CommitInfo[]>('get_commit_history', {
        path,
        limit: 100,
      });
      setCommits(history);
    } catch (error) {
      console.error('커밋 히스토리 로드 실패:', error);
    }
  };

  const loadFileChanges = async (path: string) => {
    try {
      const status = await invoke<FileStatus[]>('get_repository_status', { path });
      setFileChanges(status);
    } catch (error) {
      console.error('파일 상태 로드 실패:', error);
    }
  };

  const refresh = () => {
    if (currentRepo) {
      loadCommits(currentRepo.path);
      loadFileChanges(currentRepo.path);
    }
  };

  const handleStageFile = async (path: string) => {
    if (!currentRepo) return;
    
    await invoke('stage_file', {
      repoPath: currentRepo.path,
      filePath: path,
    });
    
    await loadFileChanges(currentRepo.path);
  };

  const handleUnstageFile = async (path: string) => {
    if (!currentRepo) return;
    
    await invoke('unstage_file', {
      repoPath: currentRepo.path,
      filePath: path,
    });
    
    await loadFileChanges(currentRepo.path);
  };

  const handleStageAll = async () => {
    if (!currentRepo) return;
    
    try {
      await invoke('stage_all', { repoPath: currentRepo.path });
      await loadFileChanges(currentRepo.path);
    } catch (error) {
      alert(`전체 스테이징 실패: ${error}`);
    }
  };

  const handleCommit = async (message: string) => {
    if (!currentRepo) return;
    
    try {
      const result = await invoke<string>('create_commit', {
        repoPath: currentRepo.path,
        message,
      });
      
      console.log(result);
      
      // 새로고침
      await loadCommits(currentRepo.path);
      await loadFileChanges(currentRepo.path);
      
      alert('커밋이 성공적으로 생성되었습니다!');
    } catch (error) {
      throw error;
    }
  };

  const stagedCount = fileChanges.filter(f => f.staged).length;

  return (
    <div className={`flex h-screen ${darkMode ? 'dark' : ''}`}>
      {/* Sidebar */}
      <Sidebar
        recentRepos={recentRepos}
        currentRepo={currentRepo}
        onSelectRepo={openRepository}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col bg-white dark:bg-gray-900">
        {/* Toolbar */}
        <div className="h-12 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 bg-gray-50 dark:bg-gray-800">
          <div className="flex items-center gap-4">
            <button
              onClick={() => openRepository()}
              className="flex items-center gap-2 px-3 py-1.5 text-sm bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
            >
              <FolderOpen size={16} />
              레포지토리 열기
            </button>
            
            {currentRepo && (
              <div className="text-sm">
                <span className="text-gray-600 dark:text-gray-400">브랜치:</span>
                <span className="ml-2 font-semibold text-gray-900 dark:text-white">
                  {currentRepo.branch}
                </span>
              </div>
            )}
            
            {currentRepo && stagedCount > 0 && (
              <button
                onClick={() => setCommitDialogOpen(true)}
                className="flex items-center gap-2 px-3 py-1.5 text-sm bg-green-500 text-white rounded hover:bg-green-600 transition-colors"
              >
                <GitCommit size={16} />
                커밋 ({stagedCount})
              </button>
            )}
          </div>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>

        {/* Content Area */}
        {!currentRepo ? (
          <div className="flex-1 flex items-center justify-center text-gray-500 dark:text-gray-400">
            <div className="text-center">
              <FolderOpen size={64} className="mx-auto mb-4 opacity-50" />
              <p className="text-lg">레포지토리를 선택하거나 열어주세요</p>
              <p className="text-sm mt-2">왼쪽 사이드바에서 최근 레포를 선택하거나</p>
              <p className="text-sm">"레포지토리 열기" 버튼을 클릭하세요</p>
            </div>
          </div>
        ) : loading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-gray-500 dark:text-gray-400">로딩 중...</div>
          </div>
        ) : (
          <div className="flex-1 flex overflow-hidden">
            {/* Left: File Changes */}
            <div className="w-80 border-r border-gray-200 dark:border-gray-700 flex flex-col">
              <FileChanges 
                files={fileChanges} 
                onRefresh={refresh}
                onStageFile={handleStageFile}
                onUnstageFile={handleUnstageFile}
                onStageAll={handleStageAll}
              />
            </div>

            {/* Right: Commit History */}
            <div className="flex-1 flex flex-col">
              <CommitHistory commits={commits} onRefresh={refresh} />
            </div>
          </div>
        )}
      </div>

      {/* Commit Dialog */}
      <CommitDialog
        isOpen={commitDialogOpen}
        onClose={() => setCommitDialogOpen(false)}
        onCommit={handleCommit}
        stagedCount={stagedCount}
      />
    </div>
  );
}

export default App;
