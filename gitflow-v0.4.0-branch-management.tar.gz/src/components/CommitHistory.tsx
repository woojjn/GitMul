import { CommitInfo } from '../App';
import { GitCommit, User, RefreshCw } from 'lucide-react';
import { useState } from 'react';

interface CommitHistoryProps {
  commits: CommitInfo[];
  onRefresh: () => void;
}

export default function CommitHistory({ commits, onRefresh }: CommitHistoryProps) {
  const [selectedCommit, setSelectedCommit] = useState<string | null>(null);

  return (
    <div className="flex flex-col h-full">
      <div className="h-12 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 bg-gray-50 dark:bg-gray-800">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <GitCommit size={18} />
          커밋 히스토리 ({commits.length})
        </h3>
        <button
          onClick={onRefresh}
          className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          title="새로고침"
        >
          <RefreshCw size={16} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {commits.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
            커밋이 없습니다
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {commits.map((commit) => (
              <div
                key={commit.id}
                onClick={() => setSelectedCommit(commit.id)}
                className={`p-4 cursor-pointer transition-colors ${
                  selectedCommit === commit.id
                    ? 'bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500'
                    : 'hover:bg-gray-50 dark:hover:bg-gray-800/50'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white text-xs font-bold">
                      {commit.author.charAt(0).toUpperCase()}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-gray-900 dark:text-white">
                        {commit.author}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {commit.date}
                      </span>
                    </div>
                    
                    <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                      {commit.message.split('\n')[0]}
                    </p>
                    
                    <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400">
                      <span className="font-mono bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded">
                        {commit.id.substring(0, 7)}
                      </span>
                      {commit.parent_ids.length > 0 && (
                        <span>
                          부모: {commit.parent_ids.length}개
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
